<?php $__env->startSection('title'); ?>
  Enregistrement des rôles | RYT
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>



<div class="row">
  <div class="col-md-12">
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
      <a class="navbar-brand" href="dashboard">Tableau De Bord</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" href="user-register">Gestion des Utilisateurs <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="projet-register">Gestions des projets</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Gestion annexe</a>
          </li>          
        </ul>
      </div>
    </nav>
  </div>
</div>

<div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <h4 class="card-title text-center"> Gestion des utilisateurs</h4>
                <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                        </div>
                <?php endif; ?>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table">
                    <thead class=" text-primary">                      
                      <th>Nom</th>
                      <th>Prénom</th>
                      <th>Email</th>
                      <th>Rôle</th>
                      <th>Nombre d'annonces</th>
                      <th>Editer</th>
                      <th>Supprimer</th>


                    </thead>
                    <tbody>                        
                              

                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>                        
                        <td> <?php echo e($user->lastname); ?></td>
                        <td> <?php echo e($user->firstname); ?></td>
                        <td> <?php echo e($user->email); ?></td>

                        <td>                 
                        <?php switch ($user->role) {
                                case 'customer':
                                  echo'Client';
                                  break;
                                case 'admin':
                                  echo"Administrateur";
                                  break;
                                case 'client':
                                  echo "Client";
                                  break;
                                case 'freelance':
                                  echo "Freelance";
                                  break;                    
                                default:
                                  echo"aucun";
                                    break;
                          } ?>
                          </td>
                          <td class="text-center">
                              <a class="nav-link" href="/projet-by-user/<?php echo e($user->id); ?>">Voir</a>
                          </td>                                               
                          <td>
                              <a href="/user-edit/<?php echo e($user->id); ?>" class="btn btn-success">Editer</a>
                          <td>
                              <form action="/user-delete/<?php echo e($user->id); ?>" method="post">
                                  <?php echo e(csrf_field()); ?>

                                  <?php echo e(method_field('DELETE')); ?>

                              <input type="hidden" name="id" value=" <?php echo e($user->id); ?>">
                              <button type="submit" class="btn btn-danger">Supprimer</button>     
                              </form>
                          </td>
                      </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>               
                                             
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        
</div>
<?php $__env->stopSection(); ?>

<script>

console.log($('#tri'));
  


if ($('#tri').val("1") == "Croissant") {
  $users = $usersinc;
} else if ($('#tri').val("2") == "Décroissant") {
  $users = $usersdesc;
}

</script>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mickael/code/iziplans/resources/views/admin/user-register.blade.php ENDPATH**/ ?>