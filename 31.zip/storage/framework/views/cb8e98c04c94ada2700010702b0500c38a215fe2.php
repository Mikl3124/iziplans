<?php $__env->startSection('content'); ?>
    <div class="container">
    <h1>Modifier mon profil</h1>
    <form action="<?php echo e(route('profil-update', Auth::user())); ?>" method="POST" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <div class="card">
            <div class="card-body">
                <?php if(Auth::user()->avatar === NULL): ?>
                    <img id="blah" class="mr-3 rounded profil-avatar" src="https://iziplans.s3.eu-west-3.amazonaws.com/images/avatar.png">
                <?php else: ?>
                    <img id="blah" class="mr-3 rounded profil-avatar" src=<?php echo e($avatar); ?>>
                <?php endif; ?>
                <input type='file' id= "upload" name="avatar" onchange="readURL(this);" />
            </div>
            
        </div>

            <button type="submit" class="btn btn-success mt-3">Enregistrer la modification</button>

    </form>
    
</div>

<script>
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#blah')
                    .attr('src', e.target.result);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mickael/code/iziplans/resources/views/users/edit.blade.php ENDPATH**/ ?>