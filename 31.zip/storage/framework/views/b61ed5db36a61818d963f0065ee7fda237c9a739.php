<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="d-flex col-md-9">
            <?php if(Auth::user()->avatar === NULL): ?>
                <img class="mr-3 mt-4 rounded profil-avatar" src="https://iziplans.s3.eu-west-3.amazonaws.com/images/avatar.png">
            <?php else: ?>
                <img class="mr-3 mt-4 rounded profil-avatar" src=<?php echo e($avatar); ?>>
            <?php endif; ?>
            <h1 class="my-auto"><?php echo e($user->firstname); ?> <?php echo e($user->lastname); ?></h1>
        </div>
        <div class="col-md-3 my-auto">
            <?php if( !empty(Auth::user()) && Auth::user()->id === $user->id): ?>
                <a href="<?php echo e(route('profil-edit', Auth::user())); ?>" class="btn btn-primary">Modifier mon profil</a>
            <?php endif; ?>
        </div>

    </div>
    

    
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mickael/code/iziplans/resources/views/users/show.blade.php ENDPATH**/ ?>