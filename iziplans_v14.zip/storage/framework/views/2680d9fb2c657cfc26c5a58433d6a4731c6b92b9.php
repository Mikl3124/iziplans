<?php $__env->startSection('title'); ?>
Edition des utilisateurs
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 class ="text-center">Edition de l'utilisateur</h3>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <form action="/user-register-update/<?php echo e($users->id); ?>" method="POST">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('PUT')); ?>


                            <div class="form-group">
                                <label>Prénom</label>
                                <input type="text" name="firstname" value="<?php echo e($users->firstname); ?>" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Nom</label>
                                <input type="text" name="lastname" value="<?php echo e($users->lastname); ?>" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>email</label>
                                <input type="text" name="email" value="<?php echo e($users->email); ?>" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Attribuer un rôle</label>
                            </div>
                            <div class="form-group">
                                <select name="role">
                                    <option value="<?php echo e($users->role); ?>"></option>
                                    <option value="admin">Administrateur</option>
                                    <option value="client">Client</option>
                                    <option value="freelance">Freelance</option>                            
                                </select>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-success">Enregistrer la modification</button>
                                <a href="/user-register" type="submit" class="btn btn-danger">Annuler la modification</a>
                            </div>
                            </form>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\iziplans\resources\views/admin/user-edit.blade.php ENDPATH**/ ?>