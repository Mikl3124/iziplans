<?php $__env->startSection('title'); ?>
  Enregistrement des annonces | RYT
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>



<div class="row">
  <div class="col-md-12">
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
      <a class="navbar-brand" href="dashboard">Tableau De Bord</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" href="/user-register">Gestion des Utilisateurs <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/projet-register">Gestions des Projets</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Gestion annexe</a>
          </li>
        </ul>
      </div>
    </nav>
  </div>
</div>

<div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <h4 class="card-title text-center"> Gestion des projets</h4>
                <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                <?php endif; ?>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table">
                    <thead class="">
                      <th>Titre</th>
                      <th>Description</th>
                      <th>Budget</th>
                      <th>Client</th>
                      <th>Status</th>
                      <th>Editer</th>
                      <th>Supprimer</th>


                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $projets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td> <?php echo e($projet->title); ?></td>
                        <td> <?php echo e($projet->description); ?></td>
                        <td> <?php echo e($projet->price); ?> €/jour</td>
                        <td> <?php echo e($projet->user->firstname); ?> <?php echo e($projet->user->lastname); ?>  </td>

                        <td>
                          <?php if($projet->status === 'pending'): ?>
                              <i class="far fa-clock icon-admin text-warning "></i>
                          <?php else: ?>
                              <i class="far fa-check-circle icon-admin text-success"></i>
                          <?php endif; ?>
                        </td>
                        <td>
                            <a href="/projet-edit/<?php echo e($projet->id); ?>" class="btn btn-success">Editer</a>
                        <td>
                            <form action="/projet-delete/<?php echo e($projet->id); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('DELETE')); ?>

                            <input type="hidden" name="id" value=" <?php echo e($projet->id); ?>">
                            <button type="submit" class="btn btn-danger">Supprimer</button>
                            </form>
                          </td>
                      </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\iziplans\resources\views/admin/projet-register.blade.php ENDPATH**/ ?>