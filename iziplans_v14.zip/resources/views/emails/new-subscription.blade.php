<h1>Hello</h1>
<p>Nouvel abonnement de {{ $user->name }}</p>
<hr>
<p>Email: {{ $user->email }}</p>


