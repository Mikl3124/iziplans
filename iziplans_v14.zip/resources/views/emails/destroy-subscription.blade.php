<h1>Hello</h1>

<p>Résiliation de {{ $user->name }}</p>
<hr>


