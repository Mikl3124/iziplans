@extends('layouts.app')

@section('content')

<h1>{{$projet->title}}</h1>
<img src={{$contents}} alt="">
@endsection
