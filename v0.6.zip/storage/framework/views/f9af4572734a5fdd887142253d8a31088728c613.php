<?php $__env->startSection('title'); ?>
    Dashboard | Iziplans
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>



<div class="row">
  <div class="col-md-12">
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
      <a class="navbar-brand" href="dashboard">Tableau De Bord</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" href="user-register">Gestion des Utilisateurs</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="projet-register">Gestions des Projets</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Donneés annexes</a>
          </li>          
        </ul>
      </div>
    </nav>
  </div>
</div>

<div class="row justify-content-center">
  <div class="col-md-6">
    <div class="card">
      <div class="card-header">
          <h4 class="card-title text-center">Données utilisateurs</h4>
      </div>

      <table class="table">
        <tbody>

          <tr>      
            <th class="">Date de la dernière inscription</th>
            <?php $__currentLoopData = $lastuser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $last): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>          
            <td><?php echo e(date('d/m/Y H:i:s', strtotime($last->created_at))); ?></td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tr>

          <tr>
            <th class=""><strong>Nombre total d'utilisateurs</strong></th>          
            <td class="text-left"><strong><?php echo e($users->count()); ?></strong></td>
          </tr>

          <tr>
            <th class="">Nombre total d'administrateurs</th>          
            <td class="text-left"><?php echo e($users->where('role', 'admin')->count()); ?></td>
          </tr> 

          <tr>
            <th class="">Nombre total de freelances</th>          
            <td><?php echo e($users->where('role', 'freelance')->count()); ?></td>
          </tr> 

          <tr>
            <th class="">Nombre total de clients</th>          
            <td><?php echo e($users->where('role', 'client')->count()); ?></td>
          </tr>                        
        </tbody>
      </table>  
    </div>
  </div>
  <div class="col-md-6">
    <div class="card">
      <div class="card-header">
          <h4 class="card-title text-center">Données projets</h4>
      </div>

      <table class="table">
        <tbody>

          <tr>      
            <th class="">Date du dernier projet</th>
            <?php $__currentLoopData = $lastprojet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $last): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>          
            <td><?php echo e(date('d/m/Y H:i:s', strtotime($last->created_at))); ?></td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tr>

          <tr>
            <th class="">Nombre total de projets</th>          
            <td><strong><?php echo e($projets->count()); ?></strong></td>
          </tr>       
                             
        </tbody>
      </table>  
    </div>
  </div>

</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mickael/code/iziplans/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>