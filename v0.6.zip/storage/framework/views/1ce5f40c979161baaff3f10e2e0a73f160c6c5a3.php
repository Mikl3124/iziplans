<?php $__env->startSection('content'); ?>

   
<div class="banner" style="background-image:url(https://iziplans.s3.eu-west-3.amazonaws.com/images/iziplans-banner.jpg)">
    <div class="container">
        <div class="display-2 text-center text-white">VOS PLANS FACILEMENT</div>
        <blockquote class="blockquote text-center">
            <p class="mb-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante.</p>
        </blockquote>
        <div class="row">
            <div class="col-md-6 col-sm-12 mt-5 text-center">
                <a class="btn btn-primary btn-lg text-center" href="#">Devenir Freelance</a>
            </div>
            <div class="col-md-6 col-sm-12 mt-5 text-center">
                <a class="btn btn-primary btn-lg " href="<?php echo e(route('projets.create')); ?>">Déposer un projet</a>
            </div>
        </div>
    </div>

</div>



</div>

<div class="container">

<div class="text-center mt-5">
        <h1 class="text-center mb-5">Comment ça marche?</h1>
        <div class="row d-flex justify-content-around">
            <div class="col-lg-3 col-sm-6">
                <div >
                    <img src="https://iziplans.s3.eu-west-3.amazonaws.com/images/paper-plane-1.png" class="card-img-iziplans" alt="demande de mission">
                    <div class="card-body">
                        <p class="card-text">Postez votre demande de mission gratuitement, pour obtenir vos offres</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6">
                <div >
                    <img src="https://iziplans.s3.eu-west-3.amazonaws.com/images/discuss-issue-1.png" class="card-img-iziplans" alt="propositions de devis">
                    <div class="card-body">
                        <p class="card-text">Recevez en moins de 24h, des propositions de prestataires qualifiés</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6">
                <div >
                    <img src="https://iziplans.s3.eu-west-3.amazonaws.com/images/choice-1.png" class="card-img-iziplans" alt="consultez les profils">
                    <div class="card-body">
                        <p class="card-text">Consultez librement les profils des prestataires et les avis pour faire votre choix</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6">
                <div >
                    <img src="https://iziplans.s3.eu-west-3.amazonaws.com/images/team-1.png" class="card-img-iziplans" alt="echangez discutez">
                    <div class="card-body">
                        <p class="card-text">Echangez, discutez et négociez sans intermédiaire, avec les prestataires de votre choix</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    

    

    <div class="text-center">
        <h1 class="text-center mt-5 mb-5">Les dernières missions proposées</h1>
    </div>
        <?php $__currentLoopData = $projets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="/projets/<?php echo e($projet->id); ?>">
            <div class="card card-project-home mb-3">

                <div class="card-body ">
                    <div class="d-flex">
                        <h2 class="list-project-title"><?php echo e($projet->title); ?> <em class="list-project-time">Posté <?php echo e(Carbon\Carbon::parse($projet->created_at)->diffForHumans()); ?></em></h2>

                    </div>
                    <div class="d-flex justify-content-around">

                        <small>Pays de la Loire</small>
                        <small>Budget :  801€ à 2500€ </small>
                        <small><?php echo e($projet->offers->count()); ?> Offres </small>
                    </div>
                    <hr>

                    <p class="card-text"><?php echo e($projet->description); ?></p>

                    <?php $__currentLoopData = $projet->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="categories"><?php echo e($category->name); ?> </span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <hr>
                    <?php $__currentLoopData = $projet->competences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $competence): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="categories"><?php echo e($competence->name); ?> </span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <div class="row d-flex justify-content-center">
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mickael/code/iziplans/resources/views/welcome.blade.php ENDPATH**/ ?>