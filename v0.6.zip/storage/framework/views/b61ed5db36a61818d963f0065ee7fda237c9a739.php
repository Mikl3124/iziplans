<?php $__env->startSection('content'); ?>
<div class="container">
    <img class="mr-3 rounded image-avatar" src="<?php echo e(Storage::disk('s3')->url(Auth::user()->avatar)); ?>">
    <h1><?php echo e($user->firstname); ?></h1>
    <a href="<?php echo e(route('profil-edit', Auth::user())); ?>" class="btn btn-primary">Modifier mon profil</a>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mickael/code/iziplans/resources/views/users/show.blade.php ENDPATH**/ ?>