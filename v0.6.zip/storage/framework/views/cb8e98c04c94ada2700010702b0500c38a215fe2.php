<?php $__env->startSection('content'); ?>
    <div class="container">
    <h1>Modifier mon profil</h1>
    <form action="<?php echo e(route('profil-update', Auth::user())); ?>" method="POST" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <div class="card">
            <div class="card-body">
                <input type='file' name="avatar" onchange="readURL(this);" />
            <img id="blah" src="<?php echo e(Storage::disk('s3')->url(Auth::user()->avatar)); ?>" alt="avatar-<?php echo e(Auth::user()->firstname); ?>" />
            </div>
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-success">Enregistrer la modification</button>
        </div>
    </form>
    
</div>

<script>
     function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#blah')
                        .attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mickael/code/iziplans/resources/views/users/edit.blade.php ENDPATH**/ ?>