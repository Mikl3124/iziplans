<?php $__env->startSection('title'); ?>
Edition des utilisateurs | RYT
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 class ="text-center">Edition des projets</h3>
                    <h4>Projet publié par <?php echo e($projet->user->firstname); ?> <?php echo e($projet->user->lastname); ?></h4>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <form action="/projet-register-update/<?php echo e($projet->id); ?>" method="POST"  enctype="multipart/form-data" >
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('PUT')); ?>


                            <div class="form-group">
                                <label>Titre</label>
                                <input type="text" name="title" value="<?php echo e($projet->title); ?>" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Description</label>
                                <input type="text" name="description" value="<?php echo e($projet->description); ?>" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Budget</label>
                                <input type="number" name="budget" value="<?php echo e($projet->budget); ?>" class="form-control">
                            </div>

                            <div class="form-group">
                                <label for="categories-projet">Selectionnez vos catégories</label>
                                <select class="form-control js-select <?php $__errorArgs = ['categories'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="categories-projet" value="<?php echo e(json_encode(old('categories'))); ?>" multiple="multiple" name="categories[]">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>" <?php echo e(in_array($category->id, old('categories') ?: []) ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['categories'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <div class="form-group">
                                <select name="status" class="custom-select mr-sm-2">
                                    <option value="pending"  <?php echo e(old('status', $projet->status) == 'pending' ? 'selected' : ''); ?>>
                                        En attente
                                    </option>
                                    <option value="publish" <?php echo e(old('status', $projet->status) == 'publish' ? 'selected' : ''); ?>>
                                        Publié
                                    </option>

                                </select>
                            </div>

                            <div class="form-group">
                                <button type="submit" class="btn btn-success">Enregistrer la modification</button>
                                <a href="/post-register" type="submit" class="btn btn-danger">Annuler la modification</a>
                            </div>
                            </form>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>


<script>

$(document).ready(function() {
    $('.js-select').select2();
});


$(() => {
    $('input[type="file"]').on('change', (e) => {
        let that = e.currentTarget
        if (that.files && that.files[0]) {
            $(that).next('.custom-file-label').html(that.files[0].name)
            let reader = new FileReader()
            reader.onload = (e) => {
                $('#preview').attr('src', e.target.result)
            }
            reader.readAsDataURL(that.files[0])
        }
    })
})

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mickael/code/iziplans/resources/views/admin/projet-edit.blade.php ENDPATH**/ ?>